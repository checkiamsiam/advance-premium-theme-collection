
import React from 'react';
import Routes from "./app/Navigations/Route";

const App = () =>{
  
  return (
    <>
      
      <Routes/>

    </>
  );
};

export default App;
