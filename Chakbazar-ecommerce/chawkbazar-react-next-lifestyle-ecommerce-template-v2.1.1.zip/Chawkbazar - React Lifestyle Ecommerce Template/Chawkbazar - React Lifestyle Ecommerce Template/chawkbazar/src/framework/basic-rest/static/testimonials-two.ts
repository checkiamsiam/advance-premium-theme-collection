export const testimonialsTwo = [
  {
    id: 1,
    avatar: {
      src: '/assets/images/testimonials/6.png',
      width: 420,
      height: 420,
    },
    rating: 4,
    name: 'Perry White',
    text: 'OMG! I cannot believe that I have got a brand new landing page after getting this template we are able to use our most used e-commerce for your branding site to make a profitable and make it cool with fast loading experience.',
  },
  {
    id: 2,
    avatar: {
      src: '/assets/images/testimonials/7.png',
      width: 420,
      height: 420,
    },
    rating: 3,
    name: 'Jiniya Snow',
    text: 'OMG! I cannot believe that I have got a brand new landing page after getting this template we are able to use our most used e-commerce for your branding site to make a profitable and make it cool with fast loading experience.',
  },
  {
    id: 3,
    avatar: {
      src: '/assets/images/testimonials/8.png',
      width: 420,
      height: 420,
    },
    rating: 5,
    name: 'Ketty Rawn',
    text: 'OMG! I cannot believe that I have got a brand new landing page after getting this template we are able to use our most used e-commerce for your branding site to make a profitable and make it cool with fast loading experience.',
  },
  {
    id: 4,
    avatar: {
      src: '/assets/images/testimonials/9.png',
      width: 420,
      height: 420,
    },
    rating: 5,
    name: 'Amanda Johnson',
    text: 'OMG! I cannot believe that I have got a brand new landing page after getting this template we are able to use our most used e-commerce for your branding site to make a profitable and make it cool with fast loading experience.',
  },
];
